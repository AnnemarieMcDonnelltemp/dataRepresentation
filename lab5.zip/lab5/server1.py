from flask import Flask, jsonify, request, abort
#from zstudentDAO import studentDAO

#my_database = db_connection.cursor()
app=Flask ( __name__, static_url_path='', static_folder= '.')

Patients= [
    {"id":1,
     "first name": "Mary",
     "Surname": "Browne",
      "Age":59,
      "Gender":"F",
      "GP": "Ken Harte"
    },
    {"id":2,
     "first name": "John",
     "Surname": "Daniels",
      "Age": 19,
      "Gender":"M",
      "GP": "Derek Shepard"
    },
    {"id":3,
     "first name": "Joshua",
     "Surname": "Jones",
      "Age":98,
      "Gender":"M",
      "GP": "Ken Harte"
    },
    {"id":4,
     "first name": "Terry",
     "Surname": "Treacy",
      "Age":37,
      "Gender":"F",
      "GP":"Judy Dench"
    }
]
nextId=5
#app=Flask(_name_)

#@app.route('/')
#def index():
#    return "Hello, World!"

@app.route('/Patients')
def getAll():
    #results=studentDAO.getAll()
    #return jsonify(results)
    return jsonify(patients)
#curl http://127.0.0.1:5000/patients

@app.route('/Patients/<int:id>')
def findById(id):
    foundPatients=list(filter(lambda b: b['id']==id, patients))
    if len(foundPatients)==0:
        return jsonify({}), 204
    return jsonify(foundPatients [0])
#curl http://127.0.0.1:5000/patients/4


@app.route('/Patients', methods=['POST'])
def create():
   
    global nextId
    if not request.json:
        abort (400)
    #other check proper formatting
    patientsu={

        "id": nextId,
        "first name": request.json['first name'],
        "Surname": request.json['Surname'],
        "Age": request.json['Age'],
        "Gender": request.json ['Gender'],
        "GP": request.json['GP'],
    }
      

    nextId +=1
    Patients.append(Patientsu)
    return jsonify(Patients)
#curl -i -H "Content-Type:application/json" -X POST -d "{\"Age\":47, \"GP\":\"Judy_Dench\", \"Gender\":\"M\", \"Surname\":\"Reacher\", \"first name\":\"Jack\", \"id\":5}" http://127.0.0.1:5000/patients
    
#eturn "in create"

@app.route('/Patients/<int:id>', methods=['PUT'])
def UPDATE(id):
    foundpatients=list(filter(lambda b:b['id']==id, Patients))
    if(len(foundpatients)== 0):
        abort(404)
    foundPatients=foundPatients[0]
    if not request.json:
        abort(400)
    reqJson=request.json
    if 'Age' in reqJson and type (reqJson['Age'])is not int:
        abort(400)

    if 'first name' in reqJson:
        foundPatients['first name'] = reqJson['first name']
    if 'Surname' in reqJson:
        foundPatients['Surname'] = reqJson['Surname']
    if 'Age' in reqJson:
        foundPatients['Age'] = reqJson['Age']
    if 'Gender' in reqJson: 
        foundPatients['Gender'] = reqJson['Gender']
    if 'GP' in reqJson: 
        foundPatients['GP'] = reqJson['GP']
    return jsonify(foundpatients)
    
    #return "in update for id"+str(id)

@app.route('/patients/<int:id>', methods=['DELETE'])
def delete(id):
    foundPatients=list(filter(lambda b:b['id']==id, patients))
    if(len(foundPatients)== 0):
        abort(404)
    patients.remove(foundPatients[0])
    return jsonify({"done":True})

    #return "in delete for id"+ str(id)

if __name__=='_main_':
    app.run(debug=True)