import mysql.connector

mydb=mysql.connector.Connect(
    host="localhost",
    user="root",
    password=""
)
mycursor=mydb.cursor()

mycursor.execute("CREATE DATABASE data")